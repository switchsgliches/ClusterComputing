#include <string>
#include <iostream>
#include "Cluster.h"
#include "Node.h"

using namespace std;

int main()
{
	Processor pros("first","second","third",1.0,1.0,2.0,1,1,1.1);
	RAM r(12);
	Power pow(12);
	Storage st(1.5);
	Node n(pros, r, pow, st);
	Cluster c1(n);

	c1.getClusterData();

	system("pause");
	return 0;
}