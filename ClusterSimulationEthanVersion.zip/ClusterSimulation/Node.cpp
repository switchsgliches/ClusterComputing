#include "Node.h"

std::string Node::getData()
{
	std::string outString = " ";

	outString += "Node Data\n";
	outString += "Processor Data:\n" + this->getData();
	outString += "RAM Data: " + std::to_string(this->getSize()) + "\n";
	outString += "Power Data: " + std::to_string(this->getPower()) + "\n";
	outString += "Storage Data: " + std::to_string(this->getStorage()) + "\n";

	return outString;
}
