// MasterNode.cpp : implementation file
//

#include "stdafx.h"
#include "MasterNode.h"
#include "afxdialogex.h"


// MasterNode dialog

IMPLEMENT_DYNAMIC(MasterNode, CDialogEx)

MasterNode::MasterNode(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_FORMVIEW, pParent)
{

}

MasterNode::~MasterNode()
{
}

void MasterNode::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(MasterNode, CDialogEx)
	ON_EN_CHANGE(IDC_EDIT1, &MasterNode::OnEnChangeEdit1)
END_MESSAGE_MAP()


// MasterNode message handlers


void MasterNode::OnEnChangeEdit1()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}
