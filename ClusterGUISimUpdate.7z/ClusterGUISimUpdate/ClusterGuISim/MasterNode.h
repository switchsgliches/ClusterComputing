#pragma once


// MasterNode dialog

class MasterNode : public CDialogEx
{
	DECLARE_DYNAMIC(MasterNode)

public:
	MasterNode(CWnd* pParent = NULL);   // standard constructor
	virtual ~MasterNode();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_FORMVIEW };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnEnChangeEdit1();
	afx_msg void OnLbnSelchangeList1();
	//string IDC_EDIT1;
	//string IDC_LIST1;
	//string IDD_FORMVIEW;
};
