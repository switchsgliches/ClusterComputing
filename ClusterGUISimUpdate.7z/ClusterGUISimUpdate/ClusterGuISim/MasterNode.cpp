// MasterNode.cpp : implementation file
//

#include "stdafx.h"
#include "MasterNode.h"
#include "afxdialogex.h"
#include "Node.h"
#include "Master.h"
#include "Slave.h"
#include <string>
#include <iostream>
//#include <afxwinforms.h>
#include <Windows.h>
#include <CommCtrl.h>
#include "resource.h"

using namespace std;

// MasterNode dialog

IMPLEMENT_DYNAMIC(MasterNode, CDialogEx)

MasterNode::MasterNode(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_FORMVIEW, pParent)
{
	
		

}

MasterNode::~MasterNode()
{
}

void MasterNode::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(MasterNode, CDialogEx)
	ON_EN_CHANGE(IDC_EDIT1, &MasterNode::OnEnChangeEdit1)
	ON_LBN_SELCHANGE(IDC_LIST1, &MasterNode::OnLbnSelchangeList1)
END_MESSAGE_MAP()


// MasterNode message handlers


void MasterNode::OnEnChangeEdit1()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	

	// TODO:  Add your control notification handler code here
	
	UpdateData(true);
	string outMaster;//between true and false has to be operation to fill box
	Master master;
	outMaster = master.getData();
	cout << outMaster;
	UpdateData(false);
}


void MasterNode::OnLbnSelchangeList1()
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
	string outNode; //between true and false has to be operation to fill box
	Node node;
	outNode = node.getData();
	UpdateData(false);
}
