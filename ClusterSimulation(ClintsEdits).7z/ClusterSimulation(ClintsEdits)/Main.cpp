#include <string>
#include <iostream>
#include "Cluster.h"
#include "Node.h"

using namespace std;

int main()
{
	Processor pros("first","second","third",1.0,1.0,2.0,1,1,1.1);
	RAM r(12);
	Power pow(12);
	Storage st(1.5);
	Node n(pros, r, pow, st);
	Cluster c1(n);

	try {
		if (_Notnull_(n, c1.getClusterData(), NULL)) {
			string theString = c1.getClusterData();
			cout << theString << endl;
			//c1.getClusterData();
		}
		else {
			cout << "there is no cluster data" << endl;
		}
	}
	catch (string e) {
		cout << "A error occurred. " << e << endl;
	}

	system("pause");
	return 0;
}